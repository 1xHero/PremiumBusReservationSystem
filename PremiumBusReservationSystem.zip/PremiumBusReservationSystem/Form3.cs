﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Data.SqlClient;

namespace PremiumBusReservationSystem
{


    public partial class Form3 : Form
    {
        

        public Form3()
        {
            InitializeComponent();

        }
        private MySqlConnection con()
        {
            MySqlConnection con = new MySqlConnection();

            con.ConnectionString = "server=127.0.0.1;user id=root;database=premiumbus;Password=toor1234;";
            return con;
        }

        private void ClearData()
        {
            
            textBox3.Text = "";
            nseat.Text = "";
            dtime.Text = "";
            atime.Text = "";
            from.Text = "";
            to.Text = "";
            tprice.Text = "";
            mdate.Text = "";
            


        }



        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {


           
           textBox3.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString(); 
          // textBox2.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
        //   textBox3.Text = (dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());


            from.Text = dataGridView1.Rows[e.RowIndex].Cells[6].Value.ToString(); 
            to.Text = dataGridView1.Rows[e.RowIndex].Cells[7].Value.ToString();
            dtime.Text = (dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString());
            atime.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            nseat.Text = (dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString());
            tprice.Text = (dataGridView1.Rows[e.RowIndex].Cells[8].Value.ToString());
            mdate.Text = (dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString());
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'premiumbusDataSet.location' table. You can move, or remove it, as needed.
            //this.locationTableAdapter.Fill(this.premiumbusDataSet.location);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
               
                string MyConnection2 = "server=127.0.0.1;user id=root;database=premiumbus;Password=toor1234;";
            
                string Query = "INSERT INTO trip (departure_time,arrival_time, numseats,freeseats, ticketprice,pfrom,pto,monthdate) VALUES('" + dtime.Text + "','" + atime.Text + "','" + nseat.Text+ "','" + nseat.Text + "','" + tprice.Text + "','" + from.Text + "','" + to.Text + "','" + mdate.Text + "');";
                
                MySqlConnection MyConn2 = new MySqlConnection(MyConnection2);
            
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                MySqlDataReader MyReader2;
                MyConn2.Open();
                MyReader2 = MyCommand2.ExecuteReader();
                MessageBox.Show("Save Data");
                while (MyReader2.Read())
                {
                }
               con().Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            ClearData();

        }

        private void button4_Click(object sender, EventArgs e)
        {
 
                 con().Open();
                 string query = "SELECT * FROM  trip";

                 DataTable myTable = new DataTable();
                 
                 MySqlCommand sda = new MySqlCommand(query, con());
                 MySqlDataAdapter returnVal = new MySqlDataAdapter(query, con());

                 returnVal.Fill(myTable);
                 
                 dataGridView1.DataSource = myTable;

                 con().Close();
            ClearData();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                
                string MyConnection2 = "server=127.0.0.1;user id=root;database=premiumbus;Password=toor1234;";
                string Query = "update trip set departure_time ='" + dtime.Text+ "', arrival_time ='" + atime.Text+ "', numseats ='" + nseat.Text + "',freeseats ='" + nseat.Text + "', ticketprice ='" + tprice.Text + "', pfrom ='" + from.Text + "' , pto ='" + to.Text + "', monthdate ='" + mdate.Text + "' where id =" + textBox3.Text+";";

                MySqlConnection MyConn2 = new MySqlConnection(MyConnection2);
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                MySqlDataReader MyReader2;
                MyConn2.Open();
                MyReader2 = MyCommand2.ExecuteReader();
                MessageBox.Show("Data Updated");
                while (MyReader2.Read())
                {
                }
                MyConn2.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            ClearData();
        }

        private void button2_Click(object sender, EventArgs e)
        {
           
            try
            {

                string MyConnection2 = "server=127.0.0.1;user id=root;database=premiumbus;Password=toor1234;";
                string Query = "delete from trip where id=" + textBox3.Text + "";

                MySqlConnection MyConn2 = new MySqlConnection(MyConnection2);
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                MySqlDataReader MyReader2;
                MyConn2.Open();
                MyReader2 = MyCommand2.ExecuteReader();
                MessageBox.Show("Data Deleted");
                while (MyReader2.Read())
                {
                }
                MyConn2.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            ClearData();

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
