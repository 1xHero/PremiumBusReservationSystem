﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Data.SqlClient;


namespace PremiumBusReservationSystem
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
     
        }

        private MySqlConnection con()
        {
            MySqlConnection con = new MySqlConnection();

            con.ConnectionString = "server=127.0.0.1;user id=root;database=premiumbus;Password=toor1234;";
            return con;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            con().Open();
            string query = "SELECT * FROM  trip";

            DataTable myTable = new DataTable();

            MySqlCommand sda = new MySqlCommand(query, con());
            MySqlDataAdapter returnVal = new MySqlDataAdapter(query, con());

            returnVal.Fill(myTable);

            dataGridView1.DataSource = myTable;

            con().Close();

        }
    }
}
